import OpenAI from "openai";
import dotenv from "dotenv";
dotenv.config();

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

interface TokenDetails {
  token_name?: string;
  ticker?: string;
  description?: string;
  image_url?: string;
  error?: string;
}

export async function parseMessage(message: string): Promise<TokenDetails> {
  const systemPrompt = `You are a token deployment parser. Extract the following fields from the user's message:
- token_name (string, required)
- ticker (string, required, max 8 characters, uppercase)
- description (string, optional)
- image_url (string, optional, must be a valid URL)
Return ONLY a valid JSON object with these fields. If a required field is missing, return an error field explaining what is missing. Do not include any other text.`;

  try {
    const chatCompletion = await openai.chat.completions.create({
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: message },
      ],
      model: "gpt-4o", // Using gpt-4o as specified
      response_format: { type: "json_object" },
    });

    const responseContent = chatCompletion.choices[0].message.content;
    if (!responseContent) {
      return { error: "No response from AI parser." };
    }

    const parsed = JSON.parse(responseContent);
    return parsed as TokenDetails;
  } catch (error) {
    console.error("Error parsing message with OpenAI:", error);
    return { error: "Failed to parse message with AI." };
  }
}
