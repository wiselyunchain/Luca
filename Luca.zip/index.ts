import dotenv from "dotenv";
dotenv.config();

import { startTelegramBot } from "./listeners/telegram";
import { startTwitterBot } from "./listeners/twitter";
import { setupQueueWorker } from "./queue/deploymentQueue";
import { createDeploymentsTable } from "./db/logger";

async function startLuca() {
  console.log("Starting Luca...");

  // Ensure database table exists
// await createDeploymentsTable(); // Commented out due to Docker limitations in sandbox

  // Start queue worker
// setupQueueWorker(); // Commented out due to Redis limitations in sandbox

  // Start platform listeners
  startTelegramBot();
  startTwitterBot();

  console.log("Luca started successfully!");
}

startLuca();
