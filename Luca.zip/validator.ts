import { Pool } from 'pg';

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

export async function validateToken(tokenName: string, ticker: string, userId: string): Promise<{ isValid: boolean; message?: string }> {
  if (tokenName.length < 1 || tokenName.length > 32) {
    return { isValid: false, message: "Token name must be between 1 and 32 characters." };
  }

  if (ticker.length < 1 || ticker.length > 8 || !/^[A-Z0-9]+$/.test(ticker)) {
    return { isValid: false, message: "Ticker must be between 1 and 8 alphanumeric characters and uppercase." };
  }

  // Check for duplicate ticker by the same user in the last 24 hours
  const result = await pool.query(
    `SELECT COUNT(*) FROM deployments WHERE user_id = $1 AND ticker = $2 AND created_at > NOW() - INTERVAL '24 HOURS'`,
    [userId, ticker]
  );

  if (result.rows[0].count > 0) {
    return { isValid: false, message: "You have already deployed a token with this ticker in the last 24 hours. Please choose a different ticker." };
  }

  return { isValid: true };
}
