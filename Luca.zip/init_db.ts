import { createDeploymentsTable } from "./logger";
import dotenv from "dotenv";
dotenv.config();

async function initDb() {
  try {
    await createDeploymentsTable();
    console.log("Database initialization complete.");
    process.exit(0);
  } catch (error) {
    console.error("Database initialization failed:", error);
    process.exit(1);
  }
}

initDb();
