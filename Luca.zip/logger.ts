import { Pool } from 'pg';

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

export async function logDeployment(deployment: {
  platform: string;
  userId: string;
  tokenName: string;
  ticker: string;
  description?: string;
  imageUrl?: string;
  contractAddress?: string;
  dexLink?: string;
  status: 'pending' | 'success' | 'failed';
  errorMessage?: string;
}) {
  const { platform, userId, tokenName, ticker, description, imageUrl, contractAddress, dexLink, status, errorMessage } = deployment;
  await pool.query(
    `INSERT INTO deployments (
      platform, user_id, token_name, ticker, description, image_url, contract_address, dex_link, status, error_message
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
    [platform, userId, tokenName, ticker, description, imageUrl, contractAddress, dexLink, status, errorMessage]
  );
}

export async function createDeploymentsTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS deployments (
      id SERIAL PRIMARY KEY,
      platform VARCHAR(20),
      user_id VARCHAR(100),
      token_name VARCHAR(100),
      ticker VARCHAR(10),
      description TEXT,
      image_url TEXT,
      contract_address VARCHAR(100),
      dex_link TEXT,
      status VARCHAR(20),
      error_message TEXT,
      created_at TIMESTAMP DEFAULT NOW()
    );
  `);
  console.log('Deployments table ensured.');
}
