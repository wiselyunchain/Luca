import { TwitterApi, ETwitterStreamEvent, TwitterApiReadWrite } from "twitter-api-v2";
import { parseMessage } from "../parser/messageParser";
import { deploymentQueue } from "../queue/deploymentQueue";
import dotenv from "dotenv";
dotenv.config();

let client: TwitterApi | undefined;
let rwClient: TwitterApiReadWrite | undefined;

if (process.env.TWITTER_API_KEY && process.env.TWITTER_API_SECRET && process.env.TWITTER_ACCESS_TOKEN && process.env.TWITTER_ACCESS_SECRET) {
  client = new TwitterApi({
    appKey: process.env.TWITTER_API_KEY as string,
    appSecret: process.env.TWITTER_API_SECRET as string,
    accessToken: process.env.TWITTER_ACCESS_TOKEN as string,
    accessSecret: process.env.TWITTER_ACCESS_SECRET as string,
  });
  rwClient = client.readWrite;
}

export async function startTwitterBot() {
  if (!process.env.TWITTER_API_KEY || !process.env.TWITTER_API_SECRET || !process.env.TWITTER_ACCESS_TOKEN || !process.env.TWITTER_ACCESS_SECRET) {
    console.error("Twitter API keys are not fully set. Twitter bot will not start.");
    return;
  }

  try {
    if (!rwClient) {
      console.error("Twitter API client (rwClient) is not initialized.");
      return;
    }
    const me = await rwClient.v2.me();
    const botId = me.data.id;
    const botUsername = me.data.username;

    console.log(`Twitter bot started. Listening for mentions of @${botUsername}`);

    if (!client || !rwClient) {
      console.error("Twitter API client not initialized. Cannot start stream.");
      return;
    }
    const stream = await client.v2.sampleStream(); // Or use filtered stream for mentions

    stream.on(ETwitterStreamEvent.Data, async (tweet) => {
      if (tweet.data.text.includes(`@${botUsername}`)) {
        const messageText = tweet.data.text;
        const userId = tweet.data.author_id;
        const platform = "twitter";
        const replyTarget = tweet.data.id;

        console.log(`Received tweet mention: ${messageText}`);

        // Acknowledge the tweet
        await rwClient.v2.reply("🔥 Luca is on it. Deploying your token now...", tweet.data.id);

        const parsedDetails = await parseMessage(messageText);

        if (parsedDetails.error) {
          await rwClient.v2.reply(`❌ Error parsing your request: ${parsedDetails.error}`, tweet.data.id);
          return;
        }

        // Add to deployment queue
        if (!deploymentQueue) {
          await rwClient.v2.reply("❌ The deployment queue is not active. Please check the server configuration.", tweet.data.id);
          console.error("Deployment queue is not initialized. Cannot add job.");
          return;
        }
        await deploymentQueue.add(
          "deploy-token",
          { platform, userId, replyTarget, ...parsedDetails },
          { attempts: 3, backoff: { type: "exponential", delay: 1000 } }
        );

        await rwClient.v2.reply("Your token deployment request has been added to the queue. I will notify you when it's live!", tweet.data.id);
      }
    });

    stream.on(ETwitterStreamEvent.Error, (error) => {
      console.error("Twitter Stream Error:", error);
    });

    stream.on(ETwitterStreamEvent.Connected, () => {
      console.log("Twitter Stream Connected.");
    });

    stream.on(ETwitterStreamEvent.ConnectionClosed, () => {
      console.log("Twitter Stream Disconnected.");
    });

  } catch (error) {
    console.error("Error starting Twitter bot:", error);
  }
}
