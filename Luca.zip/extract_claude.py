from bs4 import BeautifulSoup
import os

html_path = "/home/ubuntu/browser_html/claude_ai_d87b3638-1ad7-454a-8581-9a7732e56e9e_1779389194247.html"
with open(html_path, 'r', encoding='utf-8') as f:
    soup = BeautifulSoup(f, 'html.parser')

# Find all messages. Claude share pages usually have a specific structure.
# Let's try to find the main content area.
messages = []

# In the share page, messages are often in divs with specific classes or roles.
# Let's look for common patterns.
for msg_div in soup.find_all(['div', 'section']):
    # Check for text content that looks like a message
    text = msg_div.get_text(strip=True)
    if text:
        # We want to keep the structure if possible, but for now let's just get the text.
        # Claude's share page often uses h2 for "You said" and "Claude responded"
        pass

# Actually, let's just get all text from the root or main container to be safe.
main_content = soup.find('div', {'id': 'root'}) or soup.body
if main_content:
    print(main_content.get_text(separator='\n', strip=True))
else:
    print(soup.get_text(separator='\n', strip=True))
