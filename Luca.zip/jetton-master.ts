import { Address, beginCell, Cell, Contract, contractAddress, ContractProvider, Sender, SendMode } from "@ton/ton";

export type JettonMasterContent = {
    name: string;
    description: string;
    symbol: string;
    image: string;
};

export type JettonMasterConfig = {
    owner: Address;
    content: JettonMasterContent;
    totalSupply: bigint;
    decimals: number;
};

export function jettonMasterConfigToCell(config: JettonMasterConfig): Cell {
    const contentCell = beginCell()
        .storeUint(1, 8) // Snake format
        .storeStringTail(JSON.stringify(config.content))
        .endCell();

    return beginCell()
        .storeAddress(config.owner)
        .storeRef(contentCell)
        .storeCoins(config.totalSupply)
        .storeUint(config.decimals, 8)
        .endCell();
}

export class JettonMaster implements Contract {
    constructor(readonly address: Address, readonly init?: { code: Cell; data: Cell }) {}

    static createFromAddress(address: Address) {
        return new JettonMaster(address);
    }

    static createFromConfig(config: JettonMasterConfig, code: Cell, workchain = 0) {
        const data = jettonMasterConfigToCell(config);
        const init = { code, data };
        return new JettonMaster(contractAddress(workchain, init), init);
    }

    async sendDeploy(provider: ContractProvider, via: Sender, value: bigint) {
        await provider.internal(via, {
            value,
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell().endCell(),
        });
    }

    get initMessage() {
        return beginCell().storeUint(0x178d4519, 32).storeUint(0, 64).endCell();
    }
}
