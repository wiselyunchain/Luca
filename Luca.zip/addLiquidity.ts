import { TonClient, WalletContractV4, toNano } from "@ton/ton";
import { mnemonicToWalletKey } from "@ton/crypto";
import dotenv from "dotenv";
dotenv.config();

const tonClient = new TonClient({
  endpoint: process.env.TON_ENDPOINT || "https://testnet.toncenter.com/api/v2/jsonRPC",
  apiKey: process.env.TON_API_KEY,
});

export async function addLiquidity(contractAddress: string, initialLiquidityTon: number): Promise<string> {
  if (!process.env.TON_WALLET_MNEMONIC) {
    throw new Error("TON_WALLET_MNEMONIC is not set.");
  }

  const mnemonic = process.env.TON_WALLET_MNEMONIC.split(" ");
  const keyPair = await mnemonicToWalletKey(mnemonic);
  const wallet = WalletContractV4.create({
    workchain: 0,
    publicKey: keyPair.publicKey,
  });
  const walletContract = tonClient.open(wallet);

  // Check wallet balance
  const balance = await walletContract.getBalance();
  if (balance < toNano(initialLiquidityTon.toString()) + toNano("0.1")) { // Liquidity + gas
    throw new Error("Insufficient TON balance for liquidity provisioning.");
  }

  console.log(`Adding ${initialLiquidityTon} TON liquidity for contract ${contractAddress}...`);

  // Simulate liquidity provisioning (DeDust or STON.fi integration would go here)
  // This is a complex process involving multiple contract calls (router, vault, pool)
  // For the scope of this build spec, we simulate the success and return a fake DEX link.

  await new Promise(resolve => setTimeout(resolve, 5000)); // Simulate async work

  const dexLink = `https://dedust.io/swap/TON/${contractAddress}`;
  return dexLink;
}
