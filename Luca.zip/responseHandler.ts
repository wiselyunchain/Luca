import { Telegraf } from "telegraf";
import { TwitterApi, TwitterApiReadWrite } from "twitter-api-v2";
import dotenv from "dotenv";
dotenv.config();

const telegramBot = new Telegraf(process.env.TELEGRAM_BOT_TOKEN as string);

let rwTwitterClient: TwitterApiReadWrite | undefined;
if (process.env.TWITTER_API_KEY && process.env.TWITTER_API_SECRET && process.env.TWITTER_ACCESS_TOKEN && process.env.TWITTER_ACCESS_SECRET) {
  const twitterClient = new TwitterApi({
    appKey: process.env.TWITTER_API_KEY as string,
    appSecret: process.env.TWITTER_API_SECRET as string,
    accessToken: process.env.TWITTER_ACCESS_TOKEN as string,
    accessSecret: process.env.TWITTER_ACCESS_SECRET as string,
  });
  rwTwitterClient = twitterClient.readWrite;
} else {
  console.warn("Twitter API keys are not fully configured. Twitter responses will be skipped.");
}

interface DeploymentResult {
  platform: string;
  userId: string;
  replyTarget: string | number;
  tokenName: string;
  ticker: string;
  description?: string;
  imageUrl?: string;
  contractAddress?: string;
  dexLink?: string;
  status: "success" | "failed";
  errorMessage?: string;
}

export async function handleResponse(result: DeploymentResult) {
  const { platform, replyTarget, tokenName, ticker, description, imageUrl, contractAddress, dexLink, status, errorMessage } = result;

  if (platform === "telegram") {
    if (status === "success") {
      const message = `✅ Token Deployed Successfully!\n` +
                      `🪙 Name: ${tokenName}\n` +
                      `🔤 Ticker: ${ticker}\n` +
                      `📝 Description: ${description || "N/A"}\n` +
                      `📍 Contract: ${contractAddress}\n` +
                      `💧 Trade on DEX: ${dexLink}\n` +
                      `Powered by Luca ⚡`;
      // Telegram bot can send images directly
      if (imageUrl) {
        await telegramBot.telegram.sendPhoto(replyTarget as number, imageUrl, { caption: message });
      } else {
        await telegramBot.telegram.sendMessage(replyTarget as number, message);
      }
    } else {
      await telegramBot.telegram.sendMessage(replyTarget as number, `❌ Deployment failed. Please try again or contact support.\nError: ${errorMessage}`);
    }
  } else if (platform === "twitter") {
    if (!rwTwitterClient) {
      console.warn("Skipping Twitter response due to unconfigured API keys.");
      return;
    }

    if (status === "success") {
      const message = `✅ ${tokenName} (${ticker}) is live on TON!\n` +
                      `📍 Contract: ${contractAddress}\n` +
                      `💧 Trade: ${dexLink}\n` +
                      `Powered by @LucaBot ⚡`;
      // Twitter bot can reply with image if uploaded first
      // For simplicity, just sending text reply for now
      await rwTwitterClient.v2.reply(message, replyTarget as string);
    } else {
      await rwTwitterClient.v2.reply(`❌ Deployment failed. Please try again or contact support.\nError: ${errorMessage}`, replyTarget as string);
    }
  }
}
