import { Telegraf } from "telegraf";
import { parseMessage } from "../parser/messageParser";
import { deploymentQueue } from "../queue/deploymentQueue";
import dotenv from "dotenv";
dotenv.config();

const bot = new Telegraf(process.env.TELEGRAM_BOT_TOKEN as string);

bot.start((ctx) => ctx.reply("Welcome to Luca! I can help you deploy memecoins on TON. Just tell me the token name, ticker, and description."));
bot.help((ctx) => ctx.reply("Send me a message like: /deploy token name: MyCoin, ticker: MYC, description: A new meme coin!"));

bot.command("deploy", async (ctx) => {
  const messageText = ctx.message.text;
  const userId = ctx.from.id.toString();
  const platform = "telegram";
  const replyTarget = ctx.message.message_id;

  ctx.reply("🔥 Luca is on it. Deploying your token now...");

  const parsedDetails = await parseMessage(messageText);

  if (parsedDetails.error) {
    ctx.reply(`❌ Error parsing your request: ${parsedDetails.error}`);
    return;
  }

  // Add to deployment queue
  if (!deploymentQueue) {
    ctx.reply("❌ The deployment queue is not active. Please check the server configuration.");
    console.error("Deployment queue is not initialized. Cannot add job.");
    return;
  }
  await deploymentQueue.add(
    "deploy-token",
    { platform, userId, replyTarget, ...parsedDetails },
    { attempts: 3, backoff: { type: "exponential", delay: 1000 } }
  );

  ctx.reply("Your token deployment request has been added to the queue. I will notify you when it's live!");
});

export async function startTelegramBot() {
  if (!process.env.TELEGRAM_BOT_TOKEN) {
    console.error("TELEGRAM_BOT_TOKEN is not set. Telegram bot will not start.");
    return;
  }
  bot.launch();
  console.log("Telegram bot started.");

  // Enable graceful stop
  process.once("SIGINT", () => bot.stop("SIGINT"));
  process.once("SIGTERM", () => bot.stop("SIGTERM"));
}
