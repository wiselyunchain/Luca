import { Queue, Worker } from "bullmq";
import { generateImage } from "../image/imageGenerator";
import { deployJetton } from "../ton/deployJetton";
import { addLiquidity } from "../ton/addLiquidity";
import { validateToken } from "../validator/validator";
import { logDeployment } from "../db/logger";
import { handleResponse } from "../response/responseHandler";
import { Redis } from "ioredis";

let deploymentQueue: Queue | undefined;

export function setupQueueWorker() {
  if (!process.env.REDIS_HOST || !process.env.REDIS_PORT) {
    console.warn("Redis environment variables not fully configured. Skipping queue setup.");
    return;
  }

  const connection = new Redis({
    host: process.env.REDIS_HOST,
    port: parseInt(process.env.REDIS_PORT, 10),
    password: process.env.REDIS_PASSWORD,
    maxRetriesPerRequest: null, // Required for BullMQ
  });

  deploymentQueue = new Queue("deploymentQueue", { connection });

  new Worker(
    "deploymentQueue",
    async (job) => {
      console.log(`Processing job ${job.id} with data:`, job.data);
      let deploymentResult = {
        platform: job.data.platform,
        userId: job.data.userId,
        replyTarget: job.data.replyTarget,
        tokenName: job.data.token_name,
        ticker: job.data.ticker,
        description: job.data.description,
        imageUrl: undefined as string | undefined,
        contractAddress: undefined as string | undefined,
        dexLink: undefined as string | undefined,
        status: "failed" as "success" | "failed",
        errorMessage: undefined as string | undefined,
      };

      try {
        // 1. Validate Token
        const validation = await validateToken(job.data.token_name, job.data.ticker, job.data.userId);
        if (!validation.isValid) {
          throw new Error(validation.message);
        }

        // 2. Generate Image
        const imageUrl = await generateImage(job.data.token_name, job.data.description);
        deploymentResult.imageUrl = imageUrl;

        // 3. Deploy Jetton on TON
        const contractAddress = await deployJetton(job.data.token_name, job.data.ticker, job.data.description || "", imageUrl || "", job.data.userId);
        deploymentResult.contractAddress = contractAddress;

        // 4. Add Liquidity
        const dexLink = await addLiquidity(contractAddress, 10); // Assuming 10 TON initial liquidity
        deploymentResult.dexLink = dexLink;

        deploymentResult.status = "success";
        console.log(`Job ${job.id} completed successfully.`);
      } catch (error: any) {
        deploymentResult.errorMessage = error.message || "Unknown deployment error.";
        console.error(`Job ${job.id} failed:`, error);
      } finally {
        // Log deployment status to DB
        // await logDeployment(deploymentResult); // Commented out due to Docker limitations in sandbox
        // Send response to user
        await handleResponse(deploymentResult);
      }
      return deploymentResult;
    },
    { connection }
  );
  console.log("Deployment queue worker started.");
}

export { deploymentQueue };
