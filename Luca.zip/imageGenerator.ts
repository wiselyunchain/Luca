import OpenAI from "openai";
import dotenv from "dotenv";
dotenv.config();

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function generateImage(tokenName: string, description?: string): Promise<string | undefined> {
  const prompt = `Create a clean, bold, memecoin token logo for a token called "${tokenName}". ` +
                 `Description: ${description || ""}. ` +
                 `Style: flat icon, vibrant colors, crypto native aesthetic, circular token format, no text, no background.`;

  try {
    const response = await openai.images.generate({
      model: "dall-e-3",
      prompt: prompt,
      n: 1,
      size: "1024x1024",
    });
    if (response.data && response.data[0] && response.data[0].url) {
      return response.data[0].url;
    } else {
      console.error("DALL-E 3 response did not contain a valid image URL.");
      return undefined;
    }
  } catch (error) {
    console.error("Error generating image with DALL-E 3:", error);
    return undefined;
  }
}
