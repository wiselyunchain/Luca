import { TonClient, WalletContractV4, internal, toNano, Cell } from "@ton/ton";
import { mnemonicToWalletKey } from "@ton/crypto";
import { JettonMaster, JettonMasterConfig } from "./jetton-master";

import dotenv from "dotenv";
dotenv.config();

const tonClient = new TonClient({
  endpoint: process.env.TON_ENDPOINT || "https://testnet.toncenter.com/api/v2/jsonRPC",
  apiKey: process.env.TON_API_KEY,
});

export async function deployJetton(tokenName: string, ticker: string, description: string, imageUrl: string, ownerAddress: string): Promise<string> {
  if (!process.env.TON_WALLET_MNEMONIC) {
    throw new Error("TON_WALLET_MNEMONIC is not set.");
  }

  const mnemonic = process.env.TON_WALLET_MNEMONIC.split(" ");
  const keyPair = await mnemonicToWalletKey(mnemonic);
  const wallet = WalletContractV4.create({
    workchain: 0,
    publicKey: keyPair.publicKey,
  });
  const walletContract = tonClient.open(wallet);

  // Check wallet balance
  const balance = await walletContract.getBalance();
  if (balance < toNano("0.05")) { // Minimum balance for gas
    throw new Error("Insufficient TON balance for deployment.");
  }

  // Placeholder for jettonCode. In a real scenario, this would be compiled FunC code.
  const jettonCode = new Cell(); 

  const jettonMasterConfig: JettonMasterConfig = {
    owner: wallet.address,
    content: {
      name: tokenName,
      description: description,
      symbol: ticker,
      image: imageUrl,
    },
    totalSupply: toNano("1000000000"),
    decimals: 9,
  };

  const jettonMaster = JettonMaster.createFromConfig(jettonMasterConfig, jettonCode);

  const jettonMasterContract = tonClient.open(jettonMaster);

  const deployMessage = await walletContract.sendTransfer({
    seqno: await walletContract.getSeqno(),
    secretKey: keyPair.secretKey,
    messages: [
      internal({
        to: jettonMaster.address,
        value: toNano("0.02"), // amount for deployment
        bounce: true,
        body: jettonMaster.initMessage,
      }),
    ],
  });

  // Wait for deployment confirmation (simplified, in real app use polling)
  await new Promise(resolve => setTimeout(resolve, 15000));

  return jettonMaster.address.toString();
}
